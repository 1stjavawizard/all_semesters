#include<stdio.h>



int main(){
int x;
int y;
int sum;
double avg;
scanf("%d",&x);
scanf("%d",&y);

sum = x + y;

avg = sum / 2;



printf("The answer is %f",avg);
}
