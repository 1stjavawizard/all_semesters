#include<stdio.h>

void main(){

//for(; ;){
//   printf("This is me\n")
//}

//int k= 0;
//while(k < 10){
//printf("This is me\n");
//   k++;
//}
int p = 1;
do{
    printf("This is working\n");
    p++;
}
while(p < 5);


}
