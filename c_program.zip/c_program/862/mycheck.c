#include<stdio.h>
#include<string.h>
void main(){
int a;
printf("Enter any whole number: ");
scanf("%d",&a);
switch(a){
   case 1 ... 20:
       printf("20 is the deal");
       break;

    case 30:
       printf("30 is the deal");
       break;
    default:
        printf("Nothing matches");
        break;
}


}
