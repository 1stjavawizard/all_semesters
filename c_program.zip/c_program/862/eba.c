#include<stdio.h>
#include "meat.c";


