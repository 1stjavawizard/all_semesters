#include "b.h"

int fish( int a , int b){
  int sum = a +b;
  return sum;
}
