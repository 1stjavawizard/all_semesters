#include<stdio.h>

void main(){

//
//float p;
//float r;
//float t;
//float SI;
//printf("Enter the principle ");
//scanf("%f",&p);
//
//printf("Enter the rate: ");
//scanf("%f",&r);
//
//printf("Enter the time: ");
//scanf("%f",&t);
//
//SI = p*r*t/100;

//printf("the result is %f",SI);



for(int k = 0;k < 10;k++){
    printf("2 x %d = %d\n",k);
}



}
