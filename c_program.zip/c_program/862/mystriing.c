#include<stdio.h>
#include<string.h>

void main(){

char food[] = "rice";

char favourite[] = "RICE";

if(strcmp(food,favourite)==
   0){

  printf("This is the same");
}
else{
  printf("This is not the same");
}





}
