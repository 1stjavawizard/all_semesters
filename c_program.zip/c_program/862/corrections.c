#include<stdio.h>
#include<math.h>

int main()
{
    int p,t;
    float r,CI;

    printf("Enter principle amount :");
    scanf("%d" ,&p);

    printf("Enter rate amount :");
    scanf("%f" ,&r);

    printf("Enter time :");
    scanf("%d" ,&t);

    CI = p * pow( (1 + r / 100), t );

    printf("Compound interest is %f", CI);

    return 0;
}




// This is molabo
//#include<stdio.h>
//
//void main () {
//
///*
//START
//INPUT weight in kilograms (kg)
//INput height in meters (m)
//CALCULATE BMI using formula: BMI = weight/(height*height)
//DISPLAY the "result" for BMI
//STOP
//*/
//
//
//
//float kg;
//float m;
//float BMI;
//
//printf("Enter the weight in kilograms: ");
//scanf("%f", &kg);
//
//printf("Enter the height in meters: ");
//scanf("%f", &m);
//
//BMI = kg/(m*m);
//printf("The result is %f", BMI);
//
//
//
//
//
//}




















//samuelpeter
//#include<stdio.h>
//#include<math.h>
//
//    void main() {
//    float p;
//    float r;
//    float n;
//    float t;
//    float A;
//
//    printf("Enter the principal: ");
//    scanf("%f", &p);
//
//    printf("Enter the rate: ");
//    scanf("%f", &r);
//
//    printf("Enter the number of times interest has been compounded per year: ");
//    scanf("%f", &n);
//
//    printf("Enter the time taken: ");
//    scanf("%f", &t);
//
//    A = p * pow((1 + r / n), (n * t));
//
//    printf("The result is: %.2f\n", A);
//}




















// This is samuelpeter


//#include<stdio.h>
//
//int main() {
//    //Input
//    float weight;
//    float height;
//    float BMI;
//
//    // Process
//    printf("Enter the weight in kilograms: ");
//    scanf("%f", &weight);
//
//    printf("Enter the height in meters: ");
//    scanf("%f", &height);
//
//
//    BMI = weight / (height * height);
//
//    // Output
//    printf("Your BMI is: %.2f\n", BMI);
//
//    if (BMI < 18.5) {
//        printf("You are underweight.\n");
//    } else if (BMI >= 18.5 && BMI < 25) {
//        printf("You are within the healthy weight range.\n");
//    } else if (BMI >= 25 && BMI < 30) {
//        printf("You are overweight.\n");
//    } else {
//        printf("You are obese.\n");
//    }
//
//}
/*PSEUDOCODE FOR CALCULATING BMI
BEGIN
INPUT weight
INPUT height
INPUT BMI
BMI = weight / (height * height)
PRINT ("Your BMI is: ", BMI)
END
*/
