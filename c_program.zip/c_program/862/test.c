//#include <stdio.h>
//
//int main(){
//    printf("THIS CALCULATOR CAN ONLY MULTIPLY ANY NUMBER UP TO 12 TIMES\nANYTHING MORE THAN THAT PLEASE KINDLY CONSULT YOUR BRAIN!\n");
//for (int man =0;man<=12;man+=1){
//        int ball;
//        int cook_k_;
//printf("\n\nEnter a value you want to multiply by %d\n",man);
//scanf("%d",&cook_k_);
//    ball=cook_k_*man;
//printf("Answer = %d",ball);
//
//
//
//
//
//}
//printf("\n\n\nProudly powered by David_Chijioke the GREAT!\n\n\n\n");
//return 0;
//
//
//
//
//}
//
//    #include<stdio.h>
//
//    void main(){
//
//
//    int number;
//
//
//    printf("Enter a number for the multiplication table: ");
//    scanf("%d", &number);
//
//
//    printf("Multiplication table for %d:\n", number);
//    printf("----------------------------\n");
//    for (int i = 1; i <= 10; i++) {
//        printf("%d x %d = %d\n", number, i, number * i);
//    }
//    printf("----------------------------\n");
//
//    }

#include <stdio.h>
//
//void main(){
//
//int NUMBER;
//
//printf("WHAT TIMES TABLE DO YOU NEED:  ");
//scanf("%d", &NUMBER);
//
//for (int x=1; x<=12; x++){
//    printf("%d X %d = %d\n",NUMBER, x, NUMBER*x);
//}
//
//}




#include <stdio.h>

int main() {
    int number, a;

    // Ask user to enter a number
    printf("Enter a number to get its multiplication table: ");
    scanf("%d", &number);

    // Display the entered number multiplication table
    printf("Multiplication Table for %d:", number);
    for (a = 1; a <= 12; a++) {
        printf("\n%d x %d = %d", number, a, number * a);
    }

    return 0;
}















