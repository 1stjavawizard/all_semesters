#include<stdio.h>
#include<string.h>
#include<math.h>

void main(){
//int a[] = {10,15,16,17,18};
//
//char words[] = "come here";
//
//
//for(int i = 0; i < 4;i++){
//
//   if(a[i] == 16){
//      printf("16 is there");
//   }
//
//}
printf("%.1f",sqrt(100));
}
