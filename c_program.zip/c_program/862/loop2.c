#include<stdio.h>

void main(){

for(int i = 1; i<= 5;i++){
printf("Go %d\n",i);
    if(i % 2 == 1){
        continue;
    }

}



}
