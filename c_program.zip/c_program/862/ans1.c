#include<stdio.h>

void main(){
int tobi[] = {3,4,5};

//for(int k=0;k <= 2;k++){
//    printf("%d\n",tobi[k]);
//}

int k=0;
while(k <= 2){
   printf("%d\n",tobi[k]);
  k++;
}

//for(int k=0;k <= 2;k++){
//    if(tobi[k] == 5){
//        printf("I found it");
//    }
//
//}

}
