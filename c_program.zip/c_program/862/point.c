#include<stdio.h>

void main(){
int a = 20;

a = 40;
a = 70;
a= 100;


int* k = &a;

*k = 70;
printf("The address is %d\n",*k);
printf("The value of a is %d",a);
}
