#include<stdio.h>
#include "b.c"

void main(){

int s =fish(30, 20);

printf("%d",s);

}
