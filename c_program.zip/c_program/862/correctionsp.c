//#include <stdio.h>
//#include <stdlib.h>


//
//void main(){
//
//float balance;
//int amounttowithdraw;
//float amounttodeposit;
//int four_digit_pin = 1234;
//int anothertransaction;
//int dabus_kabash;
//
//    int choice;
//    printf("Welcome to your account Mr indaboski bahoseh and Dabus kabash :)\n\n Please kindly select transaction type \n\n");
//    printf("1. withdraw\n");
//    printf("2. deposit\n");
//    printf("3. check balance\n\n");
//    scanf("%d",&choice);
//    balance = amounttodeposit;
//
//    switch(choice){
//
//    case 1:
//    printf("Enter amount to withdraw: ");
//    scanf("%d",&amounttowithdraw);
//    if (amounttowithdraw > 0){
//        printf("please enter your 4 digit pin: ");
//        scanf("%d",&four_digit_pin);
//
//    if (four_digit_pin != 1234){
//        printf("Invalid pin!");}
//        else
//        printf("\nTransaction successful!\n");
//        break;
//        }
//
//    case 2:
//        printf("Enter amount to deposit: ");
//    scanf("%f",&amounttodeposit);
//    if (amounttodeposit > 0 && amounttodeposit!= 0){
//        printf("please enter your 4 digit pin: ");
//        scanf("%d",&four_digit_pin);
//        printf("Your balance is %f", amounttodeposit);
//
//    if (four_digit_pin != 1234){
//        printf("Invalid pin!");}
//        else
//        printf("\nTransaction successful!\n");
//        break;
//        }
//
//
//        case 3:
//    if (balance == amounttodeposit){
//        printf("please enter your 4 digit pin: ");}
//        else ("error!");
//        scanf("%d",&four_digit_pin);
//        printf("Your balance is %f", amounttodeposit);
//    if (four_digit_pin != 1234){
//        printf("Invalid pin!");}
//        else
//        printf("\n\nTransaction completed!\nKindly deposit now");
//
//
//
//    printf("\n\nDo you want to another transaction ?\nPress 1 to continue and 2 to exit: ");
//    scanf("%d",&anothertransaction);
//    if   (anothertransaction== 1){
//            int dabus_kabash;
//
//    printf("Press 2 for deposit\nPress 3 for withdrawal\nPress 4 for check balance\n");
//    scanf("%d",&dabus_kabash);
//    printf("please enter your 4 digit pin: ");
//        scanf("%d",&four_digit_pin);
//        printf("enter amount: ");
//       scanf("%d",&dabus_kabash); }
//       if (dabus_kabash == 4){
//    printf("Your balance is %f", amounttodeposit);
//       }
//
//        if (four_digit_pin != 1234){
//            printf("Invalid pin!");}
//            else
//    printf("You've successfully withdrawn from this account!");
//
//
//
//
//
//
//
//
//
//
//
//
//
//                /*printf("You've successfully deposited into this account!");/*question: how do indicate the exact amount the user deposited, for the computer to display*/
//
//
//
//    break;
//
//
//
//    }
//
//
//
//}
//


//int main()
//{
//    float total_amount,transfer,deposite,withdraw,cheak_balance;
//    int pin,password,user_input;
//
//    printf("enter your password to enter into your account\n");
//    scanf("%d", &password);
//    printf("Enter amount to create account\n");
//    scanf("%f", &total_amount);
//    printf("Enter 1 for cheak_balance.\nEnter 2 for deposite.\nEnter 3 for withdraw.\nEnter 4 for transfer.\n");
//    scanf("%d", &user_input);
//    printf("Enter pin\n");
//    scanf("%D", &pin);
//
//    if(pin==password)
//    {
//    switch (user_input)
//    {
//    case 1:
//        printf("Your total balance in your account is %f", total_amount);
//
//        break;
//    case 2:
//        printf("Enter amount to deposite\n");
//        scanf("%f", &deposite);
//        float net_balance_after;
//        net_balance_after = total_amount + deposite;
//        printf("net balance after deposite is %f", net_balance_after);
//        break;
//    case 3:
//        printf("Enter amount to withdraw\n");
//        scanf("%f", &withdraw);
//        float balabnce_after_withdraw;
//        balabnce_after_withdraw = total_amount - withdraw;
//        printf("Net balance after withdraw is %f", balabnce_after_withdraw);
//        break;
//    case 4:
//        printf("Enter amount to transfer\n");
//        scanf("%f", &transfer);
//        float balance_after_transfer;
//        balance_after_transfer = total_amount - transfer;
//        printf("Net balance after transfer is %f", balance_after_transfer);
//        break;
//
//    default:
//        printf("Enter valid user input");
//        break;
//    }
//
//    }
//    else
//    {
//        printf("Your password is wrong so repeat process again");
//    }
//
//}

//
//#include<stdio.h>
//#include<stdlib.h>
//#include<ctype.h>
//#include<string.h>
//
//int main (){
//    int service;
//    float withdrawalAmount;
//    float depositAmount;
//    float topupAmount;
//    float transferAmount;
//    float Balance = 10000.00;
//    float accountbalance;
//    char card[5];
//    char accountNo [10];
//    char bankName [20];
//    char pin[4];
//    char Exit[5];
//
//    printf("Has your card been inserted? ^__^\n");
//    scanf("%s", card);
//      // Convert the exit input string to lowercase for easier comparison
//    for (int i = 0; i <= 5; i++) {
//        card[i] = tolower(card[i]);
//    }
//
//    if (strcmp(card, "yes") == 0) {
//        printf(">>>> WELCOME TO LUCID BANK <<<<\n");
//        printf("=========== ATM MENU ===========\n");
//        printf("1. Deposit\n2. Transfer\n3. Withdrawal\n4. Topup\n5. Check account balance\n6. Exit\n");
//        printf("*********************************\n");
//        printf("Enter the service you would like to be rendered: ");
//        scanf("%d", &service);
//    }else {
//        printf("Insert your card\n");
//        }
//
//switch (service){
//    case 1:
//        printf("Enter deposit amount: \n");
//        scanf("%f", &depositAmount);
//        printf("Enter your pin: ");
//        scanf("%s", pin);
//    accountbalance = Balance + depositAmount;
//        printf("Deposit Successful\nYour new account balance is: $%.2f\n", accountbalance);
//break;
//    case 2:
//        printf("Enter beneficiary account number: \n");
//    scanf("%s", accountNo);
//            printf("Enter beneficiary bank: \n");
//        scanf("%s", bankName);
//                printf("Enter transfer amount: \n");
//            scanf("%f", &transferAmount);
//                    printf("Enter your pin: ");
//                scanf("%s", pin);
//    accountbalance = Balance - transferAmount;
//
//        if (transferAmount > Balance){
//            printf("INSUFFICIENT BALANCE\n");
//    }else {
//        printf("Transfer Successful\nYour new account balance is: $%.2f\n", accountbalance);}
//break;
//    case 3:
//        printf("Enter withdrawal amount: \n");
//        scanf("%f", &withdrawalAmount);
//        printf("Enter your pin: ");
//        scanf("%s", pin);
//    accountbalance = Balance - withdrawalAmount;
//
//        if (withdrawalAmount > Balance){
//            printf("INSUFFICIENT BALANCE\n");
//    }else{
//        printf("Withdrawal Successful\nYour new account balance is: $%.2f\n", accountbalance);}
//break;
//    case 4:
//        printf("Enter Topup amount: \n");
//        scanf("%f", &topupAmount);
//        printf("Enter your pin: ");
//        scanf("%s", pin);
//    accountbalance = Balance - topupAmount;
//        if (topupAmount > Balance){
//            printf("INSUFFICIENT BALANCE\n");
//    }else{
//        printf("Topup Successful\nYour new account balance is: $%.2f\n", accountbalance);}
//break;
//    case 5:
//        printf("Your account balance is: $%.2f\n", Balance);
//break;
//    case 6:
//        printf("Are you sure you want to exit: ");
//        scanf("%s", Exit);
//
//    // Convert the exit input string to lowercase for easier comparison
//    for (int i = 0; i <= 5; i++) {
//        Exit[i] = tolower(Exit[i]);
//    }
//        if (strcmp(Exit, "yes") == 0) {
//            printf("Exiting the program\n");
//    } else {
//        printf("Program Exit Aborted\n");
//    }
//break;
//    default:
//        printf("Invalid input, kindly choose again.\n");
// }
// printf("THANK YOU FOR ALWAYS CHOOSING OUR BANK");
//}

//#include<stdio.h>
//
//void main(){
//
//int PIN;
//int BALANCE;
//
//
//
//printf("WELCOME TO BANK419\n");
//printf("HELLO THERE, Mr.PABLO REWIRE \n");
//printf("Follow the instructions to check account balance.\n" );
//
//
//printf("INPUT YOUR PIN FOR BALANCE SHARP:   ");
//scanf("%d", &PIN);
//
//
//if (PIN == 4119) {
//    printf("CORRECT PIN!\n");
//    printf("processing...\n");
//    printf("YOUR ACCOUNT BALANCE IS: $45,875\n");
//    printf("THANK YOU FOR USING THIS SERVICE, KEEP BOMBING!\n");
//
//}
//else {
//    printf("WRONG PIN YOU THIEF!\n");
//
//}
#include<stdio.h>
//void main(){
//
//int PIN;
//int NUMBER;
//
//
//printf("WELCOME TO BANK419\n");
//printf("HELLO THERE, Mr.PABLO REWIRE \n");
//printf("Follow the instructions to transfer funds. \n" );
//
//printf("ENTER ACCOUNT NUMBER: ");
//scanf("%d", &NUMBER);
//
//printf("ACCOUNT NAME: THOMAS ANDERSON\n");
//printf("processing...\n");
//
//printf("INPUT PIN TO AUTHORIZE TRANSACTION SHARP: ");
//scanf("%d", &PIN);
//
//
//if (PIN == 4119) {
//    printf("CORRECT PIN!\n");
//    printf("processing...\n");
//    printf("TRANSFER SUCCESSFUL! \n");
//    printf("THANK YOU FOR USING THIS SERVICE, KEEP BOMBING!\n");
//
//}
//else {
//    printf("WRONG PIN YOU THIEF!\n");
//
//}
//
//
//
//
//
//
//
//
//
//
//
//}


//#include<stdio.h>
//void main(){
//
//int PIN;
//int AMOUNT;
//
//
//printf("WELCOME TO BANK419\n");
//printf("HELLO THERE, Mr.PABLO REWIRE \n");
//printf("Follow the instructions to deposit funds. \n" );
//
//printf("ENTER AMOUNT FOR DEPOSIT: $ ");
//scanf("%d", &AMOUNT);
//printf("processing...\n");
//
//printf("INPUT PIN TO AUTHORIZE TRANSACTION SHARP: ");
//scanf("%d", &PIN);
//
//
//
//if (PIN == 4119) {
//    printf("CORRECT PIN!\n");
//    printf("processing...\n");
//    printf("CASH DEPOSITED! \n");
//    printf("THANK YOU FOR USING THIS SERVICE, KEEP BOMBING!\n");
//
//}
//else {
//    printf("WRONG PIN YOU THIEF!\n");
//
//}
//
//
//
//
//
//
//}









