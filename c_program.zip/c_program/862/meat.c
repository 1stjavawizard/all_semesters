#include "meat.h";
#include<stdio.h>

float calculatebmi(float w,float h){
  float bmi = w / (h * h);
  return bmi;
}

void main(){
float ww;
float hh;
printf("Type in your weight... ");
scanf("%f",&ww);

printf("Type in your height... ");
scanf("%f",&hh);
float ans = calculatebmi(ww,hh);

printf("The answer is %.2f",ans);


}
