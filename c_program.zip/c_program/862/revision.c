#include<stdio.h>

void main(){
// 15 times
for(int counter = 1;counter <= 15;counter++){
 printf("I am here \n");
    if(counter == 5){
        continue;
    }


}

/*
char d[] = {'I','\0','a','m'}
char d[] = "I am"
*/
}
