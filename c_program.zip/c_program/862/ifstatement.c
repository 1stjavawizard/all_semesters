#include<stdio.h>

void main(){

/*

START
INPUT length(L),breadth(B)

IF length = breadth
   THEN PRINT "The shape is a square"
ELSE
  PRINT "The shape is a rectangle"

STOP
 */
int L;
int B;

printf("Enter the length: ");
scanf("%d",&L);

printf("Enter the breadth: ");
scanf("%d",&B);

if(L == B){

    printf("The shape is a square");
}

else{
    printf("The shape is a rectangle");
}






}
