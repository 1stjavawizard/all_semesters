#include <stdio.h>
#include <math.h>

//pseudo code for quadratic equation

/*BEGIN

get a,b,c

x= (-b +or - sqrt (b^2 - 4ac))/2a

WRITE ("The result is", quadratic equation)

END*/

void main(){


float b,a,c,determinant,root1,root2;

printf("Enter the value of b = ");
scanf("%f", &b);
printf("Enter the value of a = ");
scanf("%f", &a);
printf("Enter the value of c = ");
scanf("%f", &c);

determinant = b*b - 4*a*c;
root1= (- b + sqrt(determinant))/(2*a);
root2= (- b - sqrt(determinant))/(2*a);

printf ("The result for root1: %.2f\n", root1);
printf ("The result for root2: %.1f", root2);

}
