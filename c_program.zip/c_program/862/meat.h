float calculatebmi(float w,float h);



