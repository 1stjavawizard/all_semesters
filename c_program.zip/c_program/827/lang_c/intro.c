#include<stdio.h>

void main(){
float p;
float r;
float t;
float mult;
float si;
printf("Enter your principal ");
scanf("%f",&p);

printf("Enter your rate ");
scanf("%f",&r);

printf("Enter your time ");
scanf("%f",&t);

mult = p*r*t;

si = mult / 100;

printf("The simple interest is %f",si);

}
