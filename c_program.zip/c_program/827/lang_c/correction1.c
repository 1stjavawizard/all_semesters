#include<stdio.h>

void main(){

// This is single line comments
// This is another comment

/*
ALGORITHM FOR AREA OF TRAPEZIUM
START
INPUT a
INPUT b
INPUT h
sum = a+b
area =  sum/2 * h
PRINT "The area is ",area
STOP
n
*/
printf("\t\tAPPLICATION FOR AREA OF RECTANGLE\n");
float a,b,h,sum,area;
printf("Enter the value for a: ");
scanf("%f",&a);

printf("Enter the value for b: ");
scanf("%f",&b);

printf("Enter the value for h: ");
scanf("%f",&h);
sum = a+b;
area = sum/2 * h;
printf("The area is %f",area);

}
