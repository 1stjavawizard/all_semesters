#include<stdio.h>

void main(){
int kite[] = {20,30,15};

int food[4];

food[0] = 20;
food[1] = 80;
food[2] = 50;
food[3] = 200;
int sum= 0;
for(int i =1; i <= 2000; i++){
       sum += i;
// task or code you want to repeat


}
char me[10] = "What is my name";
printf("The name is %s",me);
printf("The value is %d\n",sum );
}
