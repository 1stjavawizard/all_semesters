#include<stdio.h>

void main(){

/*
switch(variable_to_be_match){
  case value1:
   // task to be executed if value1 equal to variable_to_be_match
   break;
   case value2:
    // task to be executed if value2 equal to variable_to_be_match
   break;
   default:
    // task to be executed if all values does not match
   break;
}
*/

int variable_to_be_match;
printf("Please enter any number of your choice\n");
scanf("%d",&variable_to_be_match);
switch(variable_to_be_match){
  case 10:
      printf("This is equals to 10 ");
    //task to be executed if value1 equal to variable_to_be_match
   break;
   case 20:
       printf("This is equals to 20 ");
     //task to be executed if value2 equal to variable_to_be_match
   break;
   default:
        printf("Nothing is equal for the above");
     //task to be executed if all values does not match
   break;
}


//int a = 10;
//
//int* baby;
//
//printf("Before modification %d\n",baby);
//
////*baby = 300;
//
////printf("After modification %d\n",a);
}
