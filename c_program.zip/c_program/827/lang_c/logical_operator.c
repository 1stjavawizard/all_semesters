#include<stdio.h>
#include<stdbool.h>

void main(){



/*
ALGORTHM FOR SIMPLE ARITHMETIC CALCULATOR
INPUT x
INPUT y
INPUT opr

IF opr is +
THEN
 result = x+y
ENDIF
IF opr is -
THEN
 result = x-y
IF opr is x
THEN
  result = x*y
IF opr is /
  result = x/y
PRINT "The result is ",result

*/

float x;
float y;
char opr;
float result;

printf("Enter the first number: ");
scanf("%f",&x);

printf("Enter the second number: ");
scanf("%f",&y);

printf("Enter the operator(/,x,-,+): ");
scanf("%c",&opr);

if(opr == '+'){
   result = x+y;
}
if(opr == '-'){
     result = x-y;
}
if(opr == 'x'){
    result = x*y;
}
if(opr == '/'){
    result = x/y;
}

printf("The result is %f",result);


























































/*
if(20 < 10){
 //task to be executed if  conditions is true
 printf("This actually worked!!");

}
else{
    printf("This is just false");
}
*/

/*
bool first = !(20 > 30);
bool second = !(10 < 15);

//bool combine = first || second;

//bool combine2 = 20 > 30 || 10 < 15;

printf("The first result is %d\n",first);
printf("The second result is %d\n",second);

//printf("The combine result is %d\n",combine);

*/
/*
if(combine){
    printf("This combine is true or 1");
}

if(20 > 30 || 10 < 15){}
*/
/*
bool first = 20 > 30;
bool second = 10 < 15;

bool combine = first || second;

bool combine2 = 20 > 30 || 10 < 15;

printf("The first result is %d\n",first);
printf("The second result is %d\n",second);

printf("The combine result is %d\n",combine);

if(combine){
    printf("This combine is true or 1");
}

if(20 > 30 || 10 < 15){}


*/







/*
bool first = 20 < 30;
bool second = 10 < 15;

bool combine = first && second;

bool combine2 = 20 > 30 && 10 < 15;

printf("The first result is %d\n",first);
printf("The second result is %d\n",second);

printf("The combine result is %d\n",combine);

if(combine){
    printf("This combine is true or 1");
}

if(20 > 30 && 10 < 15){}

    */

}
