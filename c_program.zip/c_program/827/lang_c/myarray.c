#include<stdio.h>

void main(){

char sub[10];

printf("enter your name\n");

scanf("%s",sub);

printf("%s",sub);

}
