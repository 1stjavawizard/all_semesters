#include<stdio.h>

void main(){
char ops;

printf("Enter any operator: ");
 scanf("%c",ops);
 switch(ops){
  case '+':
     printf("%c",ops);
     break;
 }


}
