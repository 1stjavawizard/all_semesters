#include<stdio.h>
#include<stdbool.h>

int main(){

bool truthy = true;
int a = 20;
int checker = (a > 20);
printf("The value is %d",checker);

/*
if(a == 20){
    printf("This worked");
}
*/

}
